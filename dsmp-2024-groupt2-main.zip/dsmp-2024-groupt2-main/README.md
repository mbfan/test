# Group Repository for the Data Science Mini-Project (EMATM0050)

## Please edit the fields below with your information
Group Number: T2

Problem Assigned: Sapienza University

Group Members: 4 members

